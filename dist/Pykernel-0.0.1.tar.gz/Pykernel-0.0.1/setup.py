from setuptools import setup
setup(
    name="Pykernel",
    version="0.0.1",
    description="Python & text Windows CMD Editior written with only native libaries",
    py_modules=["pykernel"],
    package_dir={"":"code"}
)